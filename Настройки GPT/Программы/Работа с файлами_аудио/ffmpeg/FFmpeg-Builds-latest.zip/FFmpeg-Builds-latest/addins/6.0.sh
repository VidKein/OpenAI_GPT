#!/bin/bash
GIT_BRANCH="release/6.0"
